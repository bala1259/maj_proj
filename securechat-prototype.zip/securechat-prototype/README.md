# SecureChat - Real-Time Encrypted Messaging Application

A full-stack secure messaging application with session-based multi-layered encryption, built as a BTech major project prototype.

## Features

- **Real-time messaging** with WebSocket connections
- **Dual-layer encryption** using AES-256-GCM and ChaCha20-Poly1305
- **Daily algorithm rotation** for enhanced security
- **Session-based key management** with forward secrecy
- **Modern web interface** with professional UI
- **Two hardcoded user accounts** for testing (no login required)

## Architecture

### Backend (Python + FastAPI)
- FastAPI web server with WebSocket support
- Real-time message broadcasting
- Session management with unique encryption keys
- Daily rotating algorithm dictionary
- In-memory storage (easily replaceable with database)

### Frontend (HTML + JavaScript)
- Modern responsive design with Tailwind CSS
- Real-time chat interface
- Client-side encryption before transmission
- Session management and status indicators
- Support for multiple chat sessions

### Encryption Layers
1. **Layer 1**: AES-256-GCM or ChaCha20-Poly1305 (randomly selected)
2. **Layer 2**: Different algorithm from Layer 1 (randomly selected)
3. **Transport**: WSS (WebSocket Secure) over HTTPS

## Quick Start

### Prerequisites
- Python 3.8+
- Modern web browser
- pip (Python package manager)

### Setup Instructions

1. **Clone/Download the project files**
   ```bash
   mkdir securechat-prototype
   cd securechat-prototype
   ```

2. **Set up Python environment**
   ```bash
   python -m venv venv
   source venv/bin/activate  # On Windows: venv\Scripts\activate
   pip install -r requirements.txt
   ```

3. **Start the backend server**
   ```bash
   python main.py
   ```
   Server will start on `http://localhost:8000`

4. **Open the frontend**
   - Open `index.html` in your web browser
   - Or serve it via a simple HTTP server:
   ```bash
   python -m http.server 8080
   ```
   Then open `http://localhost:8080`

## Usage

### User Accounts
The application comes with two pre-configured accounts:
- **22h51a62c7-2004** (User Alpha)
- **22h51a62c7r-2004r** (User Beta)

### Testing the Application

1. **Open two browser windows/tabs**
2. **Select different users** in each window
3. **Start a new chat session** in one window
4. **Begin messaging** - messages are encrypted with dual-layer encryption
5. **Monitor encryption status** in the UI

### API Endpoints

- `GET /` - Health check
- `GET /api/algorithms` - Get today's algorithm rotation
- `GET /api/users` - List all users
- `POST /api/session` - Create new chat session
- `GET /api/user/{user_id}/sessions` - Get user's sessions
- `WebSocket /ws/{user_id}` - Real-time messaging

## File Structure

```
securechat-prototype/
├── main.py                 # FastAPI backend server
├── algorithms_dict.py      # Algorithm dictionary and rotation
├── encryption_service.py   # Two-layer encryption service
├── requirements.txt        # Python dependencies
├── crypto_modules/
│   ├── aes_gcm.py         # AES-256-GCM implementation
│   └── chacha20_poly1305.py # ChaCha20-Poly1305 implementation
├── static/
│   ├── index.html         # Main web interface
│   ├── style.css          # Modern UI styling
│   └── app.js             # Frontend application logic
└── README.md              # This file
```

## Security Features

### Encryption
- **AES-256-GCM**: Authenticated encryption with 256-bit keys
- **ChaCha20-Poly1305**: Stream cipher with authentication
- **Random key generation** for each session
- **Secure nonce/IV generation** for each message

### Session Management
- **Unique session IDs** using UUID4
- **Per-session encryption keys** (not shared between sessions)
- **Algorithm randomization** per session
- **Forward secrecy** through key rotation

### Daily Algorithm Rotation
- **Date-based seeding** for reproducible daily rotation
- **Algorithm ID obfuscation** (users see IDs, not names)
- **Automatic rotation** at midnight

## Development

### Running Tests
```bash
# Test individual crypto modules
python crypto_modules/aes_gcm.py
python crypto_modules/chacha20_poly1305.py

# Test encryption service
python encryption_service.py

# Test backend API
python -m pytest  # (if tests are implemented)
```

### Adding New Algorithms
1. Create new module in `crypto_modules/`
2. Implement `encrypt()` and `decrypt()` functions
3. Add to `ALGORITHMS` dict in `algorithms_dict.py`
4. Update `EncryptionService` to load the new module

### Production Deployment
- Replace in-memory storage with database (PostgreSQL recommended)
- Add proper user authentication and authorization
- Enable HTTPS/WSS with SSL certificates
- Add rate limiting and DDoS protection
- Implement proper logging and monitoring

## Technology Stack

- **Backend**: Python 3.8+, FastAPI, WebSockets, Cryptography
- **Frontend**: HTML5, CSS3 (Tailwind), Vanilla JavaScript
- **Encryption**: AES-256-GCM, ChaCha20-Poly1305
- **Communication**: WebSocket (WSS in production)
- **Storage**: In-memory (demo), PostgreSQL (production)

## License

This project is created for educational purposes as a BTech major project prototype.

## Contributing

This is a prototype application. For production use, consider:
- Implementing proper user management
- Adding persistent storage
- Enhanced error handling
- Comprehensive testing suite
- Security auditing
- Performance optimization

## Support

For issues or questions about this BTech project:
1. Check the console for error messages
2. Verify all dependencies are installed
3. Ensure Python 3.8+ is being used
4. Check that ports 8000 and 8080 are available