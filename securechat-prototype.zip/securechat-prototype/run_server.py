#!/usr/bin/env python3
"""
SecureChat Application Runner
Starts the FastAPI backend server for the secure messaging application
"""

import sys
import os
import time

def check_python_version():
    """Check if Python version is 3.8 or higher"""
    if sys.version_info < (3, 8):
        print("Error: Python 3.8 or higher is required")
        print(f"Current version: {sys.version}")
        sys.exit(1)

def check_dependencies():
    """Check if required dependencies are installed"""
    required_packages = [
        'fastapi',
        'uvicorn',
        'cryptography',
        'websockets'
    ]
    
    missing_packages = []
    for package in required_packages:
        try:
            __import__(package)
        except ImportError:
            missing_packages.append(package)
    
    if missing_packages:
        print(f"Error: Missing required packages: {', '.join(missing_packages)}")
        print("Please run: pip install -r requirements.txt")
        sys.exit(1)

def start_server():
    """Start the FastAPI server"""
    print("Starting SecureChat Backend Server...")
    print("=" * 50)
    
    try:
        # Import uvicorn for server
        import uvicorn
        
        # Import main app
        from main import app
        
        print("✓ FastAPI app loaded successfully")
        print("✓ Starting server on http://localhost:8000")
        print("✓ WebSocket endpoint: ws://localhost:8000/ws/{user_id}")
        print("✓ API documentation: http://localhost:8000/docs")
        print("\nPress Ctrl+C to stop the server")
        print("=" * 50)
        
        # Start server
        uvicorn.run(
            app,
            host="0.0.0.0",
            port=8000,
            reload=True,
            log_level="info"
        )
        
    except ImportError as e:
        if 'uvicorn' in str(e):
            print("Error: uvicorn is not installed")
            print("Please run: pip install uvicorn")
        elif 'main' in str(e):
            print(f"Error importing application: {e}")
            print("Make sure main.py exists in the current directory")
        else:
            print(f"Error importing dependencies: {e}")
        sys.exit(1)
    except Exception as e:
        print(f"Error starting server: {e}")
        sys.exit(1)

def show_usage():
    """Display usage instructions"""
    print("\nSecureChat - Real-Time Encrypted Messaging")
    print("=" * 45)
    print("\nTo use the application:")
    print("1. Keep this server running")
    print("2. Open index.html in your web browser")
    print("3. Select a user account (22h51a62c7-2004 or 22h51a62c7r-2004r)")
    print("4. Start chatting with dual-layer encryption!")
    print("\nUser Accounts:")
    print("- User Alpha: 22h51a62c7-2004")
    print("- User Beta:  22h51a62c7r-2004r")
    print("\nAPI Endpoints:")
    print("- Health Check: http://localhost:8000/")
    print("- Algorithms:   http://localhost:8000/api/algorithms")
    print("- Users:        http://localhost:8000/api/users")
    print("- Docs:         http://localhost:8000/docs")

if __name__ == "__main__":
    print("SecureChat Backend - Starting Up...")
    
    # Check system requirements
    check_python_version()
    print("✓ Python version check passed")
    
    check_dependencies()
    print("✓ Dependencies check passed")
    
    # Show usage information
    show_usage()
    
    # Wait a moment then start server
    print("\nStarting server in 3 seconds...")
    time.sleep(3)
    
    # Start the server
    start_server()
