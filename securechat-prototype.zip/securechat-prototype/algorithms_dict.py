"""
algorithms_dict.py
Authoritative master list of algorithms + daily-rotation helpers
"""

import random
import datetime
from typing import Dict, Tuple

# ---------------------------------------------------------------------------
# MASTER LIST – DO NOT SHUFFLE
# key = master-id (permanent)        value = python-module name in crypto_modules
# ---------------------------------------------------------------------------
ALGORITHMS: Dict[int, str] = {
    1: "aes_gcm",
    2: "chacha20_poly1305",
    3: "blowfish_cbc",
    4: "rsa_oaep",
    5: "ecdsa_p256",
}

# ---------------------------------------------------------------------------
# DAILY MAPPING  (client-visible IDs → master IDs)
# ---------------------------------------------------------------------------
def _date_seed() -> int:
    """Return an int seed that changes once per day."""
    return datetime.date.today().toordinal()

def get_daily_mapping() -> Dict[int, int]:
    """
    Create / return the same pseudo-random mapping for the current day.
    Example output for a given day:  {1:3, 2:5, 3:1, 4:4, 5:2}
    Meaning: daily id 1  ↦ master id 3  (‘blowfish_cbc’)
    """
    master_ids = list(ALGORITHMS.keys())
    rng = random.Random(_date_seed())
    rng.shuffle(master_ids)
    return {i + 1: master_ids[i] for i in range(len(master_ids))}

# Convenience ---------------------------------------------------------------

def daily_id_to_module_name(daily_id: int) -> str:
    daily_map = get_daily_mapping()
    try:
        master_id = daily_map[daily_id]
        return ALGORITHMS[master_id]
    except KeyError:
        raise ValueError(f"Invalid daily algorithm id: {daily_id}")

def select_session_algorithms() -> Tuple[int, int]:
    """
    Randomly choose *two different* daily IDs for a session.
    Returns (layer1_daily_id, layer2_daily_id)
    """
    daily_ids = list(get_daily_mapping().keys())
    return tuple(random.sample(daily_ids, 2))
# ------------------------------------------------------------------
# Back-compatibility shim for the legacy test-suite
# ------------------------------------------------------------------
def get_daily_algorithms():
    """
    Legacy alias kept only for the SecureChat test-suite.
    Returns: the same dict produced by get_daily_mapping().
    """
    return get_daily_mapping()
