# main.py - FastAPI Backend for SecureChat
import asyncio
import json
import uuid
from datetime import datetime, date
from typing import Dict, List, Optional
import logging

from fastapi import FastAPI, WebSocket, WebSocketDisconnect, HTTPException
from fastapi.middleware.cors import CORSMiddleware
from pydantic import BaseModel
import uvicorn

# Configure logging
logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)

# Data models
class Message(BaseModel):
    id: str
    sender_id: str
    session_id: str
    encrypted_content: str
    timestamp: datetime
    algorithm_layers: List[int]

class Session(BaseModel):
    id: str
    participants: List[str]
    created_at: datetime
    algorithm_layer1: int
    algorithm_layer2: int
    status: str = "active"

class User(BaseModel):
    id: str
    name: str
    status: str = "offline"

# Application state
app = FastAPI(title="SecureChat Backend", version="1.0.0")

# CORS middleware for development
app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],  # In production, specify exact origins
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

# In-memory storage (use database in production)
users: Dict[str, User] = {
    "22h51a62c7-2004": User(id="22h51a62c7-2004", name="User Alpha"),
    "22h51a62c7r-2004r": User(id="22h51a62c7r-2004r", name="User Beta")
}

sessions: Dict[str, Session] = {}
messages: Dict[str, List[Message]] = {}
active_connections: Dict[str, WebSocket] = {}

# Algorithm dictionary with daily rotation
ALGORITHMS = {
    1: "AES-256-GCM",
    2: "ChaCha20-Poly1305", 
    3: "RSA-2048",
    4: "ECDSA-P256",
    5: "Blowfish"
}

def get_daily_algorithms():
    """Generate daily algorithm rotation based on date"""
    import random
    today = date.today()
    seed = today.toordinal()
    rng = random.Random(seed)
    
    # Shuffle algorithm IDs for daily rotation
    algo_ids = list(ALGORITHMS.keys())
    rng.shuffle(algo_ids)
    
    # Return rotated mapping
    return {i+1: ALGORITHMS[algo_ids[i]] for i in range(len(algo_ids))}

def generate_session_algorithms():
    """Select two random algorithms for a new session"""
    import random
    daily_algos = get_daily_algorithms()
    selected_ids = random.sample(list(daily_algos.keys()), 2)
    return selected_ids[0], selected_ids[1]

# WebSocket connection manager
class ConnectionManager:
    def __init__(self):
        self.active_connections: Dict[str, WebSocket] = {}

    async def connect(self, websocket: WebSocket, user_id: str):
        await websocket.accept()
        self.active_connections[user_id] = websocket
        users[user_id].status = "online"
        logger.info(f"User {user_id} connected")
        
        # Broadcast user status update
        await self.broadcast_user_status(user_id, "online")

    def disconnect(self, user_id: str):
        if user_id in self.active_connections:
            del self.active_connections[user_id]
            users[user_id].status = "offline"
            logger.info(f"User {user_id} disconnected")

    async def send_personal_message(self, message: str, user_id: str):
        if user_id in self.active_connections:
            websocket = self.active_connections[user_id]
            try:
                await websocket.send_text(message)
            except Exception as e:
                logger.error(f"Error sending message to {user_id}: {e}")
                self.disconnect(user_id)

    async def broadcast_to_session(self, session_id: str, message: str, exclude_user: str = None):
        if session_id in sessions:
            session = sessions[session_id]
            for participant in session.participants:
                if participant != exclude_user and participant in self.active_connections:
                    await self.send_personal_message(message, participant)

    async def broadcast_user_status(self, user_id: str, status: str):
        status_message = json.dumps({
            "type": "user_status",
            "user_id": user_id,
            "status": status,
            "timestamp": datetime.now().isoformat()
        })
        
        for connected_user in self.active_connections.keys():
            if connected_user != user_id:
                await self.send_personal_message(status_message, connected_user)

manager = ConnectionManager()

# API Endpoints
@app.get("/")
async def root():
    return {"message": "SecureChat Backend API", "status": "running"}

@app.get("/api/algorithms")
async def get_algorithms():
    """Get today's algorithm rotation"""
    daily_algos = get_daily_algorithms()
    return {
        "algorithm_ids": list(daily_algos.keys()),
        "rotation_date": date.today().isoformat()
    }

@app.get("/api/users")
async def get_users():
    """Get all users and their status"""
    return {"users": list(users.values())}

@app.get("/api/user/{user_id}")
async def get_user(user_id: str):
    """Get specific user details"""
    if user_id not in users:
        raise HTTPException(status_code=404, detail="User not found")
    return users[user_id]

@app.post("/api/session")
async def create_session(participants: List[str]):
    """Create a new chat session"""
    # Validate participants
    for participant in participants:
        if participant not in users:
            raise HTTPException(status_code=400, detail=f"User {participant} not found")
    
    # Generate session
    session_id = str(uuid.uuid4())
    layer1, layer2 = generate_session_algorithms()
    
    session = Session(
        id=session_id,
        participants=participants,
        created_at=datetime.now(),
        algorithm_layer1=layer1,
        algorithm_layer2=layer2
    )
    
    sessions[session_id] = session
    messages[session_id] = []
    
    logger.info(f"Created session {session_id} with algorithms {layer1}, {layer2}")
    
    # Notify participants
    session_message = json.dumps({
        "type": "session_created",
        "session": session.dict(),
        "timestamp": datetime.now().isoformat()
    })
    
    for participant in participants:
        await manager.send_personal_message(session_message, participant)
    
    return session

@app.get("/api/session/{session_id}")
async def get_session(session_id: str):
    """Get session details"""
    if session_id not in sessions:
        raise HTTPException(status_code=404, detail="Session not found")
    return sessions[session_id]

@app.get("/api/session/{session_id}/messages")
async def get_messages(session_id: str):
    """Get messages for a session"""
    if session_id not in sessions:
        raise HTTPException(status_code=404, detail="Session not found")
    return {"messages": messages.get(session_id, [])}

@app.get("/api/user/{user_id}/sessions")
async def get_user_sessions(user_id: str):
    """Get all sessions for a user"""
    if user_id not in users:
        raise HTTPException(status_code=404, detail="User not found")
    
    user_sessions = [session for session in sessions.values() 
                    if user_id in session.participants]
    return {"sessions": user_sessions}

# WebSocket endpoint
@app.websocket("/ws/{user_id}")
async def websocket_endpoint(websocket: WebSocket, user_id: str):
    if user_id not in users:
        await websocket.close(code=4004, reason="User not found")
        return
    
    await manager.connect(websocket, user_id)
    
    try:
        while True:
            data = await websocket.receive_text()
            message_data = json.loads(data)
            
            if message_data["type"] == "message":
                await handle_message(message_data, user_id)
            elif message_data["type"] == "ping":
                await handle_ping(user_id)
            elif message_data["type"] == "session_request":
                await handle_session_request(message_data, user_id)
            else:
                logger.warning(f"Unknown message type: {message_data['type']}")
                
    except WebSocketDisconnect:
        manager.disconnect(user_id)
        await manager.broadcast_user_status(user_id, "offline")
    except Exception as e:
        logger.error(f"WebSocket error for user {user_id}: {e}")
        manager.disconnect(user_id)

async def handle_message(message_data: dict, sender_id: str):
    """Handle incoming encrypted message"""
    session_id = message_data.get("session_id")
    encrypted_content = message_data.get("encrypted_content")
    algorithm_layers = message_data.get("algorithm_layers", [])
    
    if not session_id or session_id not in sessions:
        logger.error(f"Invalid session_id: {session_id}")
        return
    
    # Create message record
    message = Message(
        id=str(uuid.uuid4()),
        sender_id=sender_id,
        session_id=session_id,
        encrypted_content=encrypted_content,
        timestamp=datetime.now(),
        algorithm_layers=algorithm_layers
    )
    
    # Store message
    if session_id not in messages:
        messages[session_id] = []
    messages[session_id].append(message)
    
    # Broadcast to session participants
    broadcast_message = json.dumps({
        "type": "message",
        "message": message.dict(),
        "timestamp": datetime.now().isoformat()
    })
    
    await manager.broadcast_to_session(session_id, broadcast_message, exclude_user=sender_id)
    logger.info(f"Message broadcast to session {session_id}")

async def handle_ping(user_id: str):
    """Handle ping request"""
    pong_message = json.dumps({
        "type": "pong",
        "timestamp": datetime.now().isoformat()
    })
    await manager.send_personal_message(pong_message, user_id)

async def handle_session_request(message_data: dict, user_id: str):
    """Handle session creation request"""
    participants = message_data.get("participants", [user_id])
    
    # Validate participants
    valid_participants = [p for p in participants if p in users]
    
    if len(valid_participants) < 2:
        error_message = json.dumps({
            "type": "error",
            "message": "Need at least 2 valid participants",
            "timestamp": datetime.now().isoformat()
        })
        await manager.send_personal_message(error_message, user_id)
        return
    
    # Create session via API logic
    session_id = str(uuid.uuid4())
    layer1, layer2 = generate_session_algorithms()
    
    session = Session(
        id=session_id,
        participants=valid_participants,
        created_at=datetime.now(),
        algorithm_layer1=layer1,
        algorithm_layer2=layer2
    )
    
    sessions[session_id] = session
    messages[session_id] = []
    
    # Notify all participants
    session_message = json.dumps({
        "type": "session_created",
        "session": session.dict(),
        "timestamp": datetime.now().isoformat()
    })
    
    for participant in valid_participants:
        await manager.send_personal_message(session_message, participant)

# Health check endpoint
@app.get("/health")
async def health_check():
    return {
        "status": "healthy",
        "timestamp": datetime.now().isoformat(),
        "active_connections": len(manager.active_connections),
        "active_sessions": len(sessions),
        "total_messages": sum(len(msgs) for msgs in messages.values())
    }

if __name__ == "__main__":
    uvicorn.run(
        "main:app",
        host="0.0.0.0",
        port=8000,
        reload=True,
        log_level="info"
    )