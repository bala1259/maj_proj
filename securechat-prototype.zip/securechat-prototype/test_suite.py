#!/usr/bin/env python3
"""
SecureChat Test Suite
Tests the encryption modules and core functionality
"""

import sys
import os
import json
import base64

def test_aes_gcm():
    """Test AES-GCM encryption module"""
    print("Testing AES-256-GCM...")
    try:
        # Import the module directly
        sys.path.append('.')
        from crypto_modules.aes_gcm import encrypt, decrypt, generate_key
        
        # Test data
        key = generate_key()
        message = "Hello, SecureChat! This is an AES-GCM test."
        
        # Encrypt
        encrypted = encrypt(message, key)
        print(f"✓ Encryption successful: {encrypted['algorithm']}")
        
        # Decrypt
        decrypted = decrypt(encrypted, key)
        print(f"✓ Decryption successful")
        
        # Verify
        if message == decrypted:
            print("✓ AES-GCM test PASSED")
            return True
        else:
            print("✗ AES-GCM test FAILED - messages don't match")
            return False
            
    except ImportError as e:
        print(f"✗ AES-GCM test FAILED - Import error: {e}")
        return False
    except Exception as e:
        print(f"✗ AES-GCM test FAILED - {e}")
        return False

def test_chacha20():
    """Test ChaCha20-Poly1305 encryption module"""
    print("\nTesting ChaCha20-Poly1305...")
    try:
        from crypto_modules.chacha20_poly1305 import encrypt, decrypt, generate_key
        
        # Test data
        key = generate_key()
        message = "Hello, SecureChat! This is a ChaCha20 test."
        
        # Encrypt
        encrypted = encrypt(message, key)
        print(f"✓ Encryption successful: {encrypted['algorithm']}")
        
        # Decrypt
        decrypted = decrypt(encrypted, key)
        print(f"✓ Decryption successful")
        
        # Verify
        if message == decrypted:
            print("✓ ChaCha20-Poly1305 test PASSED")
            return True
        else:
            print("✗ ChaCha20-Poly1305 test FAILED - messages don't match")
            return False
            
    except ImportError as e:
        print(f"✗ ChaCha20-Poly1305 test FAILED - Import error: {e}")
        return False
    except Exception as e:
        print(f"✗ ChaCha20-Poly1305 test FAILED - {e}")
        return False

def test_algorithm_dict():
    """Test algorithm dictionary and rotation"""
    print("\nTesting Algorithm Dictionary...")
    try:
        from algorithms_dict import get_daily_algorithms, select_session_algorithms
        
        # Test daily algorithms
        daily_algos = get_daily_algorithms()
        print(f"✓ Daily algorithms loaded: {len(daily_algos)} algorithms")
        
        # Test session selection
        layer1, layer2 = select_session_algorithms()
        print(f"✓ Session algorithms selected: {layer1}, {layer2}")
        
        if layer1 != layer2:
            print("✓ Algorithm dictionary test PASSED")
            return True
        else:
            print("✗ Algorithm dictionary test FAILED - same algorithm selected twice")
            return False
            
    except ImportError as e:
        print(f"✗ Algorithm dictionary test FAILED - Import error: {e}")
        return False
    except Exception as e:
        print(f"✗ Algorithm dictionary test FAILED - {e}")
        return False

def test_encryption_service():
    """Test the main encryption service"""
    print("\nTesting Encryption Service...")
    try:
        from encryption_service import EncryptionService
        
        # Create service
        service = EncryptionService()
        print("✓ Encryption service created")
        
        # Create session config
        config = service.create_session_encryption_config()
        print(f"✓ Session config created: {config['session_id'][:8]}...")
        
        # Test message encryption
        message = "Hello, SecureChat! This is a two-layer encryption test."
        encrypted = service.encrypt_message(message, config)
        print("✓ Message encrypted successfully")
        
        # Test message decryption
        decrypted = service.decrypt_message(encrypted, config)
        print("✓ Message decrypted successfully")
        
        # Verify
        if message == decrypted:
            print("✓ Encryption service test PASSED")
            return True
        else:
            print("✗ Encryption service test FAILED - messages don't match")
            print(f"Original:  {message}")
            print(f"Decrypted: {decrypted}")
            return False
            
    except ImportError as e:
        print(f"✗ Encryption service test FAILED - Import error: {e}")
        return False
    except Exception as e:
        print(f"✗ Encryption service test FAILED - {e}")
        return False

def test_api_imports():
    """Test that FastAPI components can be imported"""
    print("\nTesting API Components...")
    try:
        import websockets
        print("✓ FastAPI and dependencies imported successfully")
        
        # Test main app import
        from main import app
        print("✓ Main application imported successfully")
        
        print("✓ API components test PASSED")
        return True
        
    except ImportError as e:
        print(f"✗ API components test FAILED - Import error: {e}")
        print("Please run: pip install -r requirements.txt")
        return False
    except Exception as e:
        print(f"✗ API components test FAILED - {e}")
        return False

def run_all_tests():
    """Run all tests and return overall result"""
    print("SecureChat Test Suite")
    print("=" * 50)
    
    tests = [
        test_aes_gcm,
        test_chacha20,
        test_algorithm_dict,
        test_encryption_service,
        test_api_imports
    ]
    
    results = []
    for test in tests:
        try:
            result = test()
            results.append(result)
        except Exception as e:
            print(f"✗ Test failed with exception: {e}")
            results.append(False)
    
    # Summary
    print("\n" + "=" * 50)
    print("TEST SUMMARY")
    print("=" * 50)
    
    passed = sum(results)
    total = len(results)
    
    print(f"Tests passed: {passed}/{total}")
    
    if passed == total:
        print("🎉 ALL TESTS PASSED! Application is ready to run.")
        print("\nTo start the application:")
        print("1. Run: python run_server.py")
        print("2. Open index.html in your browser")
        print("3. Select user account and start chatting!")
        return True
    else:
        print("❌ Some tests failed. Please check the errors above.")
        return False

if __name__ == "__main__":
    success = run_all_tests()
    sys.exit(0 if success else 1)