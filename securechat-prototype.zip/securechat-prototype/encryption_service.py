"""
encryption_service.py
Creates per-session configs and performs two-layer encryption / decryption.
"""

import json
import uuid
from typing import Dict, Any

from algorithms_dict import (
    select_session_algorithms,
    daily_id_to_module_name,
)
from crypto_modules import get_module


class EncryptionService:
    # --------------------------------------------------------------------- #
    # PUBLIC API                                                            #
    # --------------------------------------------------------------------- #
    def create_session_encryption_config(self) -> Dict[str, Any]:
        """
        Returns a dict that the front-end can store with the message thread.
        {
            "session_id": str,
            "layer1_id": int,   # daily ID (NOT the master id)
            "layer2_id": int,   # daily ID (NOT the master id)
            "key1": str(base64),    # JSON-serialisable keys
            "key2": str(base64)
        }
        """
        layer1_id, layer2_id = select_session_algorithms()

        mod1 = get_module(daily_id_to_module_name(layer1_id))
        mod2 = get_module(daily_id_to_module_name(layer2_id))

        key1 = mod1.generate_key()
        key2 = mod2.generate_key()

        return {
            "session_id": uuid.uuid4().hex,
            "layer1_id": layer1_id,
            "layer2_id": layer2_id,
            # store keys as base64 strings so they survive JSON round-trip
            "key1": _b64(key1),
            "key2": _b64(key2),
        }

    def encrypt_message(self, plaintext: str, cfg: Dict[str, Any]) -> Dict[str, Any]:
        """
        Encrypt → returns nested dict ready for transport / storage
        """
        # Layer 1 -----------------------------------------------------------
        mod1 = get_module(daily_id_to_module_name(cfg["layer1_id"]))
        key1 = _b64d(cfg["key1"])
        layer1_ct = mod1.encrypt(plaintext, key1)           # returns dict
        layer1_blob = json.dumps(layer1_ct).encode()

        # Layer 2 -----------------------------------------------------------
        mod2 = get_module(daily_id_to_module_name(cfg["layer2_id"]))
        key2 = _b64d(cfg["key2"])
        layer2_ct = mod2.encrypt(layer1_blob, key2)        # returns dict

        return layer2_ct  # outermost ciphertext dict

    def decrypt_message(self, ciphertext: Dict[str, Any], cfg: Dict[str, Any]) -> str:
        """
        Reverse of encrypt_message(); returns original plaintext string.
        """
        # Layer 2  (reverse order) -----------------------------------------
        mod2 = get_module(daily_id_to_module_name(cfg["layer2_id"]))
        key2 = _b64d(cfg["key2"])
        layer1_blob = mod2.decrypt(ciphertext, key2)       # -> bytes or str
        if isinstance(layer1_blob, str):                   # <— new
            layer1_blob = layer1_blob.encode()             # <— new


        # Layer 1 -----------------------------------------------------------
        mod1 = get_module(daily_id_to_module_name(cfg["layer1_id"]))
        key1 = _b64d(cfg["key1"])
        layer1_ct = json.loads(layer1_blob.decode())
        plaintext = mod1.decrypt(layer1_ct, key1)

        return plaintext


# ------------------------------------------------------------------------- #
# Helper functions                                                          #
# ------------------------------------------------------------------------- #
import base64

def _b64(data: bytes) -> str:
    return base64.b64encode(data).decode()

def _b64d(text: str) -> bytes:
    return base64.b64decode(text)
