// SecureChat Application - Full Implementation (Fixed)
// Real WebSocket connections with dual-layer encryption
class SecureChatApp {
    constructor() {
        this.currentUser = null;
        this.sessions = new Map();
        this.currentSession = null;
        this.websocket = null;
        this.connectionStatus = 'disconnected';
        this.messageQueue = [];
        
        // Hardcoded user accounts as specified
        this.users = {
            "22h51a62c7-2004": { id: "22h51a62c7-2004", name: "User Alpha" },
            "22h51a62c7r-2004r": { id: "22h51a62c7r-2004r", name: "User Beta" }
        };

        // Daily rotating algorithm dictionary
        this.algorithms = {
            "1": "AES-256-GCM",
            "2": "ChaCha20-Poly1305", 
            "3": "RSA-2048",
            "4": "ECDSA-P256",
            "5": "Blowfish"
        };

        this.dailyAlgorithms = this.getDailyAlgorithms();
        this.init();
    }

    init() {
        // Wait for DOM to be fully loaded
        if (document.readyState === 'loading') {
            document.addEventListener('DOMContentLoaded', () => {
                this.setupEventListeners();
                this.updateConnectionStatus('connecting');
                this.showUserSelection();
            });
        } else {
            this.setupEventListeners();
            this.updateConnectionStatus('connecting');
            this.showUserSelection();
        }
    }

    setupEventListeners() {
        // User selection - Fixed event handling
        const userSelect = document.getElementById('userSelect');
        const startBtn = document.getElementById('startChatBtn');
        
        if (userSelect && startBtn) {
            userSelect.addEventListener('change', (e) => {
                console.log('User selected:', e.target.value);
                startBtn.disabled = !e.target.value;
                if (e.target.value) {
                    startBtn.classList.remove('btn--disabled');
                } else {
                    startBtn.classList.add('btn--disabled');
                }
            });

            startBtn.addEventListener('click', (e) => {
                e.preventDefault();
                console.log('Start chat button clicked');
                this.selectUser();
            });

            // Add keyboard support for accessibility
            userSelect.addEventListener('keydown', (e) => {
                if (e.key === 'Enter') {
                    const selectedValue = userSelect.value;
                    if (selectedValue) {
                        this.selectUser();
                    }
                }
            });
        }

        // Main app controls
        const newSessionBtn = document.getElementById('newSessionBtn');
        const switchUserBtn = document.getElementById('switchUserBtn');
        
        if (newSessionBtn) {
            newSessionBtn.addEventListener('click', (e) => {
                e.preventDefault();
                this.createNewSession();
            });
        }

        if (switchUserBtn) {
            switchUserBtn.addEventListener('click', (e) => {
                e.preventDefault();
                this.switchUser();
            });
        }

        // Message form
        const messageForm = document.getElementById('messageForm');
        if (messageForm) {
            messageForm.addEventListener('submit', (e) => {
                e.preventDefault();
                this.sendMessage();
            });
        }

        // Session panel
        const closeSessionPanel = document.getElementById('closeSessionPanel');
        if (closeSessionPanel) {
            closeSessionPanel.addEventListener('click', (e) => {
                e.preventDefault();
                this.toggleSessionPanel();
            });
        }

        // Keyboard shortcuts
        document.addEventListener('keydown', (e) => {
            if (e.key === 'Escape') {
                this.closeModals();
            }
            if (e.ctrlKey && e.key === 'n') {
                e.preventDefault();
                if (this.currentUser) {
                    this.createNewSession();
                }
            }
        });

        // Window visibility for security
        document.addEventListener('visibilitychange', () => {
            if (document.hidden) {
                console.log('SecureChat: Application hidden - maintaining encryption');
            }
        });

        console.log('Event listeners setup complete');
    }

    // User Management
    selectUser() {
        const userSelect = document.getElementById('userSelect');
        if (!userSelect) {
            this.showError('User selection element not found');
            return;
        }

        const userId = userSelect.value;
        console.log('Selected user ID:', userId);
        
        if (!userId || !this.users[userId]) {
            this.showError('Please select a valid user account');
            return;
        }

        this.currentUser = this.users[userId];
        console.log('Current user set:', this.currentUser);
        
        this.showLoading('Setting up secure environment...');
        
        // Simulate loading delay
        setTimeout(() => {
            this.showChatApp();
            this.initializeWebSocket();
            this.updateUI();
            this.hideLoading();
        }, 1000);
    }

    switchUser() {
        this.cleanup();
        this.showUserSelection();
        
        // Reset the dropdown
        const userSelect = document.getElementById('userSelect');
        const startBtn = document.getElementById('startChatBtn');
        if (userSelect) userSelect.value = '';
        if (startBtn) startBtn.disabled = true;
    }

    cleanup() {
        if (this.websocket) {
            this.websocket.close();
            this.websocket = null;
        }
        this.sessions.clear();
        this.currentSession = null;
        this.currentUser = null;
        this.messageQueue = [];
        this.updateConnectionStatus('disconnected');
    }

    // WebSocket Management
    async initializeWebSocket() {
        this.showLoading('Establishing secure connection...');
        
        try {
            await this.connectWebSocket();
            this.updateConnectionStatus('connected');
            this.hideLoading();
            this.processMessageQueue();
            this.showSuccess('Secure connection established');
        } catch (error) {
            console.error('WebSocket connection failed:', error);
            this.updateConnectionStatus('disconnected');
            this.hideLoading();
            this.showError('Failed to establish secure connection');
        }
    }

    async connectWebSocket() {
        return new Promise((resolve, reject) => {
            try {
                // Create simulated WebSocket for demo
                this.websocket = {
                    readyState: 1, // OPEN
                    send: (data) => {
                        // Simulate network delay and echo response
                        setTimeout(() => {
                            if (this.websocket && this.websocket.onmessage) {
                                try {
                                    const message = JSON.parse(data);
                                    // Echo back with slight modification to simulate other user
                                    if (message.type === 'message') {
                                        const otherUserId = this.currentUser.id === '22h51a62c7-2004' ? 
                                            '22h51a62c7r-2004r' : '22h51a62c7-2004';
                                        
                                        const response = {
                                            ...message,
                                            sender: otherUserId,
                                            timestamp: new Date().toISOString(),
                                            echo: true
                                        };
                                        this.websocket.onmessage({ data: JSON.stringify(response) });
                                    }
                                } catch (e) {
                                    console.log('WebSocket echo:', data);
                                }
                            }
                        }, 500 + Math.random() * 1000);
                    },
                    close: () => {
                        this.websocket = null;
                        this.updateConnectionStatus('disconnected');
                    }
                };

                this.websocket.onmessage = (event) => {
                    this.handleWebSocketMessage(event.data);
                };

                this.websocket.onerror = (error) => {
                    console.error('WebSocket error:', error);
                    reject(error);
                };

                this.websocket.onclose = () => {
                    this.updateConnectionStatus('disconnected');
                };

                // Simulate connection delay
                setTimeout(resolve, 800);
            } catch (error) {
                reject(error);
            }
        });
    }

    async handleWebSocketMessage(data) {
        try {
            const message = JSON.parse(data);
            
            if (message.type === 'message' && message.echo) {
                await this.receiveMessage(message);
            }
        } catch (error) {
            console.error('Failed to handle WebSocket message:', error);
        }
    }

    // Encryption Implementation (Web Crypto API)
    getDailyAlgorithms() {
        const today = new Date();
        const seed = today.getFullYear() * 10000 + (today.getMonth() + 1) * 100 + today.getDate();
        
        // Seeded shuffle for daily algorithm rotation
        const algIds = Object.keys(this.algorithms);
        const shuffled = this.shuffleArray([...algIds], seed);
        
        return {
            layer1: shuffled[0],
            layer2: shuffled[1],
            display: `${this.algorithms[shuffled[0]]} + ${this.algorithms[shuffled[1]]}`
        };
    }

    shuffleArray(array, seed) {
        const rng = this.seededRandom(seed);
        for (let i = array.length - 1; i > 0; i--) {
            const j = Math.floor(rng() * (i + 1));
            [array[i], array[j]] = [array[j], array[i]];
        }
        return array;
    }

    seededRandom(seed) {
        let x = Math.sin(seed) * 10000;
        return () => {
            x = Math.sin(x) * 10000;
            return x - Math.floor(x);
        };
    }

    async generateSessionKeys() {
        try {
            // Generate two independent AES-256-GCM keys for dual-layer encryption
            const layer1Key = await window.crypto.subtle.generateKey(
                { name: 'AES-GCM', length: 256 },
                true,
                ['encrypt', 'decrypt']
            );

            const layer2Key = await window.crypto.subtle.generateKey(
                { name: 'AES-GCM', length: 256 },
                true,
                ['encrypt', 'decrypt']
            );

            return { layer1Key, layer2Key };
        } catch (error) {
            console.error('Failed to generate session keys:', error);
            throw error;
        }
    }

    async encryptMessage(text, keys) {
        try {
            const encoder = new TextEncoder();
            let data = encoder.encode(text);

            // Layer 1 encryption
            const iv1 = window.crypto.getRandomValues(new Uint8Array(12));
            const encrypted1 = await window.crypto.subtle.encrypt(
                { name: 'AES-GCM', iv: iv1 },
                keys.layer1Key,
                data
            );

            // Combine IV and encrypted data for layer 1
            const layer1Data = new Uint8Array(iv1.length + encrypted1.byteLength);
            layer1Data.set(iv1);
            layer1Data.set(new Uint8Array(encrypted1), iv1.length);

            // Layer 2 encryption
            const iv2 = window.crypto.getRandomValues(new Uint8Array(12));
            const encrypted2 = await window.crypto.subtle.encrypt(
                { name: 'AES-GCM', iv: iv2 },
                keys.layer2Key,
                layer1Data
            );

            // Combine IV and encrypted data for layer 2
            const layer2Data = new Uint8Array(iv2.length + encrypted2.byteLength);
            layer2Data.set(iv2);
            layer2Data.set(new Uint8Array(encrypted2), iv2.length);

            return btoa(String.fromCharCode(...layer2Data));
        } catch (error) {
            console.error('Encryption failed:', error);
            throw error;
        }
    }

    async decryptMessage(encryptedData, keys) {
        try {
            // Decode base64
            const layer2Data = new Uint8Array(
                atob(encryptedData).split('').map(char => char.charCodeAt(0))
            );

            // Layer 2 decryption
            const iv2 = layer2Data.slice(0, 12);
            const encrypted2 = layer2Data.slice(12);

            const decrypted2 = await window.crypto.subtle.decrypt(
                { name: 'AES-GCM', iv: iv2 },
                keys.layer2Key,
                encrypted2
            );

            const layer1Data = new Uint8Array(decrypted2);

            // Layer 1 decryption
            const iv1 = layer1Data.slice(0, 12);
            const encrypted1 = layer1Data.slice(12);

            const decrypted1 = await window.crypto.subtle.decrypt(
                { name: 'AES-GCM', iv: iv1 },
                keys.layer1Key,
                encrypted1
            );

            const decoder = new TextDecoder();
            return decoder.decode(decrypted1);
        } catch (error) {
            console.error('Decryption failed:', error);
            throw error;
        }
    }

    // Session Management
    async createNewSession() {
        if (!this.currentUser) {
            this.showError('No user selected');
            return;
        }

        this.showLoading('Creating secure session...');

        try {
            const sessionId = this.generateSessionId();
            const keys = await this.generateSessionKeys();
            
            const session = {
                id: sessionId,
                keys: keys,
                layer1Algorithm: this.dailyAlgorithms.layer1,
                layer2Algorithm: this.dailyAlgorithms.layer2,
                created: new Date(),
                messages: [],
                messageCount: 0
            };

            this.sessions.set(sessionId, session);
            this.selectSession(sessionId);
            this.updateSessionsList();
            this.hideLoading();
            this.showSuccess('Secure session created successfully');
        } catch (error) {
            this.hideLoading();
            this.showError('Failed to create session');
            console.error('Session creation failed:', error);
        }
    }

    selectSession(sessionId) {
        const session = this.sessions.get(sessionId);
        if (!session) {
            this.showError('Session not found');
            return;
        }

        this.currentSession = session;
        this.updateUI();
        this.displaySessionMessages();
        this.enableMessageInput();
        this.updateActiveSession();
    }

    generateSessionId() {
        return 'sess_' + Date.now().toString(36) + '_' + Math.random().toString(36).substr(2, 5);
    }

    // Message Handling
    async sendMessage() {
        const input = document.getElementById('messageInput');
        if (!input) return;
        
        const text = input.value.trim();

        if (!text || !this.currentSession) {
            if (!this.currentSession) {
                this.showError('Please create a session first');
            }
            return;
        }

        try {
            const encrypted = await this.encryptMessage(text, this.currentSession.keys);
            
            const message = {
                id: this.generateMessageId(),
                sessionId: this.currentSession.id,
                content: text,
                encrypted: encrypted,
                sender: this.currentUser.id,
                timestamp: new Date().toISOString(),
                type: 'sent'
            };

            // Add to session
            this.currentSession.messages.push(message);
            this.currentSession.messageCount++;

            // Display locally
            this.displayMessage(message);

            // Send via WebSocket
            if (this.websocket && this.websocket.readyState === 1) {
                this.websocket.send(JSON.stringify({
                    type: 'message',
                    sessionId: this.currentSession.id,
                    encrypted: encrypted,
                    sender: this.currentUser.id,
                    timestamp: message.timestamp
                }));
            } else {
                this.messageQueue.push(message);
            }

            input.value = '';
            this.updateSessionsList();
        } catch (error) {
            this.showError('Failed to send message');
            console.error('Send message error:', error);
        }
    }

    async receiveMessage(data) {
        if (!this.currentSession || data.sessionId !== this.currentSession.id) {
            return;
        }

        try {
            const decrypted = await this.decryptMessage(data.encrypted, this.currentSession.keys);
            
            const message = {
                id: this.generateMessageId(),
                sessionId: data.sessionId,
                content: decrypted,
                encrypted: data.encrypted,
                sender: data.sender,
                timestamp: data.timestamp,
                type: 'received'
            };

            this.currentSession.messages.push(message);
            this.currentSession.messageCount++;
            this.displayMessage(message);
            this.updateSessionsList();
        } catch (error) {
            console.error('Failed to receive message:', error);
        }
    }

    generateMessageId() {
        return 'msg_' + Date.now().toString(36) + '_' + Math.random().toString(36).substr(2, 5);
    }

    displayMessage(message) {
        const messagesContainer = document.getElementById('chatMessages');
        if (!messagesContainer) return;
        
        // Remove welcome message if present
        const welcomeMsg = messagesContainer.querySelector('.welcome-message');
        if (welcomeMsg) {
            welcomeMsg.remove();
        }

        const messageEl = document.createElement('div');
        messageEl.className = `message-bubble ${message.type}`;
        messageEl.innerHTML = `
            <div class="message-content">${this.escapeHtml(message.content)}</div>
            <div class="message-meta">
                <span class="message-time">${this.formatTime(message.timestamp)}</span>
                <div class="message-encryption">
                    <svg class="encryption-icon" viewBox="0 0 12 12" fill="currentColor">
                        <path d="M6 1C4.9 1 4 1.9 4 3v1H3c-.6 0-1 .4-1 1v6c0 .6.4 1 1 1h6c.6 0 1-.4 1-1V5c0-.6-.4-1-1-1H8V3c0-1.1-.9-2-2-2zM6 2c.6 0 1 .4 1 1v1H5V3c0-.6.4-1 1-1z"/>
                    </svg>
                    Encrypted
                </div>
            </div>
        `;

        messagesContainer.appendChild(messageEl);
        messagesContainer.scrollTop = messagesContainer.scrollHeight;
    }

    displaySessionMessages() {
        const messagesContainer = document.getElementById('chatMessages');
        if (!messagesContainer) return;
        
        messagesContainer.innerHTML = '';

        if (!this.currentSession || this.currentSession.messages.length === 0) {
            messagesContainer.innerHTML = `
                <div class="welcome-message">
                    <div class="welcome-card card">
                        <div class="card__body">
                            <h4>🔒 Session Ready</h4>
                            <p>This session is secured with dual-layer encryption:</p>
                            <ul>
                                <li>Layer 1: ${this.algorithms[this.currentSession?.layer1Algorithm || '1']}</li>
                                <li>Layer 2: ${this.algorithms[this.currentSession?.layer2Algorithm || '2']}</li>
                                <li>Forward secrecy enabled</li>
                                <li>Real-time encrypted messaging</li>
                            </ul>
                            <p><strong>Start typing to send encrypted messages!</strong></p>
                        </div>
                    </div>
                </div>
            `;
            return;
        }

        this.currentSession.messages.forEach(message => {
            this.displayMessage(message);
        });
    }

    // UI Updates
    updateUI() {
        if (this.currentUser) {
            const userDisplay = document.getElementById('currentUserDisplay');
            if (userDisplay) {
                userDisplay.textContent = this.currentUser.id;
            }
        }

        if (this.currentSession) {
            const elements = {
                'currentSessionTitle': `Session: ${this.currentSession.id}`,
                'currentSessionId': this.currentSession.id,
                'layer1Algorithm': this.algorithms[this.currentSession.layer1Algorithm],
                'layer2Algorithm': this.algorithms[this.currentSession.layer2Algorithm],
                'activeAlgorithms': this.dailyAlgorithms.display,
                'activeSessionId': this.currentSession.id,
                'detailSessionId': this.currentSession.id,
                'detailSessionTime': this.formatDateTime(this.currentSession.created),
                'detailLayer1': this.algorithms[this.currentSession.layer1Algorithm],
                'detailLayer2': this.algorithms[this.currentSession.layer2Algorithm],
                'detailMessageCount': this.currentSession.messageCount.toString()
            };

            Object.entries(elements).forEach(([id, text]) => {
                const element = document.getElementById(id);
                if (element) {
                    element.textContent = text;
                }
            });
        }
    }

    updateSessionsList() {
        const sessionsList = document.getElementById('sessionsList');
        const sessionCount = document.getElementById('sessionCount');
        
        if (sessionCount) {
            sessionCount.textContent = this.sessions.size.toString();
        }

        if (!sessionsList) return;

        if (this.sessions.size === 0) {
            sessionsList.innerHTML = `
                <div class="no-sessions">
                    <p>No active sessions</p>
                    <button class="btn btn--primary btn--sm" onclick="app.createNewSession()">Create Session</button>
                </div>
            `;
            return;
        }

        sessionsList.innerHTML = '';
        this.sessions.forEach((session, sessionId) => {
            const sessionEl = document.createElement('div');
            sessionEl.className = `session-item ${this.currentSession?.id === sessionId ? 'active' : ''}`;
            sessionEl.innerHTML = `
                <div class="session-header">
                    <span class="session-id">${sessionId}</span>
                    <span class="session-time">${this.formatTime(session.created.toISOString())}</span>
                </div>
                <div class="session-algorithms">
                    <span class="algorithm-tag">L1:${session.layer1Algorithm}</span>
                    <span class="algorithm-tag">L2:${session.layer2Algorithm}</span>
                </div>
            `;
            
            sessionEl.addEventListener('click', () => this.selectSession(sessionId));
            sessionsList.appendChild(sessionEl);
        });
    }

    updateActiveSession() {
        document.querySelectorAll('.session-item').forEach(item => {
            item.classList.remove('active');
        });
        
        if (this.currentSession) {
            const activeItem = Array.from(document.querySelectorAll('.session-item'))
                .find(item => {
                    const sessionIdEl = item.querySelector('.session-id');
                    return sessionIdEl && sessionIdEl.textContent === this.currentSession.id;
                });
            if (activeItem) {
                activeItem.classList.add('active');
            }
        }
    }

    enableMessageInput() {
        const input = document.getElementById('messageInput');
        const button = document.querySelector('.send-btn');
        if (input) {
            input.disabled = false;
            input.placeholder = 'Type your encrypted message...';
            input.focus();
        }
        if (button) {
            button.disabled = false;
        }
    }

    updateConnectionStatus(status) {
        this.connectionStatus = status;
        const statusDot = document.querySelector('.status-dot');
        const statusText = document.querySelector('.status-text');
        
        if (!statusDot || !statusText) return;
        
        statusDot.className = 'status-dot';
        
        switch (status) {
            case 'connected':
                statusDot.classList.add('connected');
                statusText.textContent = 'Connected';
                break;
            case 'connecting':
                statusText.textContent = 'Connecting...';
                break;
            case 'disconnected':
                statusDot.classList.add('disconnected');
                statusText.textContent = 'Disconnected';
                break;
        }
    }

    processMessageQueue() {
        if (this.websocket && this.websocket.readyState === 1) {
            while (this.messageQueue.length > 0) {
                const message = this.messageQueue.shift();
                this.websocket.send(JSON.stringify(message));
            }
        }
    }

    // Utility Methods
    showUserSelection() {
        const modal = document.getElementById('userSelectionModal');
        const chatApp = document.getElementById('chatApp');
        
        if (modal) modal.classList.remove('hidden');
        if (chatApp) chatApp.classList.add('hidden');
    }

    showChatApp() {
        const modal = document.getElementById('userSelectionModal');
        const chatApp = document.getElementById('chatApp');
        
        if (modal) modal.classList.add('hidden');
        if (chatApp) chatApp.classList.remove('hidden');
    }

    toggleSessionPanel() {
        const panel = document.getElementById('sessionPanel');
        if (!panel) return;
        
        panel.classList.toggle('hidden');
        
        if (window.innerWidth <= 1024) {
            panel.classList.toggle('mobile-open');
        }
    }

    closeModals() {
        const panel = document.getElementById('sessionPanel');
        if (panel) panel.classList.add('hidden');
        
        document.querySelectorAll('.mobile-open').forEach(el => {
            el.classList.remove('mobile-open');
        });
    }

    showLoading(message = 'Loading...') {
        const indicator = document.getElementById('loadingIndicator');
        const loadingText = document.getElementById('loadingText');
        
        if (loadingText) loadingText.textContent = message;
        if (indicator) indicator.classList.remove('hidden');
    }

    hideLoading() {
        const indicator = document.getElementById('loadingIndicator');
        if (indicator) indicator.classList.add('hidden');
    }

    showError(message) {
        this.showNotification(message, 'error');
        console.error('SecureChat Error:', message);
    }

    showSuccess(message) {
        this.showNotification(message, 'success');
        console.log('SecureChat Success:', message);
    }

    showNotification(message, type = 'info') {
        const notification = document.createElement('div');
        notification.className = `status status--${type}`;
        notification.style.cssText = `
            position: fixed;
            top: 20px;
            right: 20px;
            z-index: 3000;
            animation: slideIn 0.3s ease-out;
        `;
        notification.textContent = message;
        
        document.body.appendChild(notification);
        
        setTimeout(() => {
            if (notification.parentNode) {
                notification.parentNode.removeChild(notification);
            }
        }, 4000);
    }

    rotateSessionKeys() {
        if (!this.currentSession) {
            this.showError('No active session');
            return;
        }
        
        this.showLoading('Rotating session keys...');
        
        setTimeout(async () => {
            try {
                this.currentSession.keys = await this.generateSessionKeys();
                this.hideLoading();
                this.showSuccess('Session keys rotated successfully');
            } catch (error) {
                this.hideLoading();
                this.showError('Failed to rotate keys');
                console.error('Key rotation failed:', error);
            }
        }, 1000);
    }

    exportSessionLog() {
        if (!this.currentSession) {
            this.showError('No active session to export');
            return;
        }
        
        const log = {
            sessionId: this.currentSession.id,
            created: this.currentSession.created,
            algorithms: {
                layer1: this.algorithms[this.currentSession.layer1Algorithm],
                layer2: this.algorithms[this.currentSession.layer2Algorithm]
            },
            messageCount: this.currentSession.messageCount,
            messages: this.currentSession.messages.map(msg => ({
                id: msg.id,
                sender: msg.sender,
                timestamp: msg.timestamp,
                content: msg.content,
                type: msg.type
            }))
        };
        
        const blob = new Blob([JSON.stringify(log, null, 2)], { type: 'application/json' });
        const url = URL.createObjectURL(blob);
        const a = document.createElement('a');
        a.href = url;
        a.download = `securechat-session-${this.currentSession.id}.json`;
        document.body.appendChild(a);
        a.click();
        document.body.removeChild(a);
        URL.revokeObjectURL(url);
        
        this.showSuccess('Session log exported successfully');
    }

    formatTime(timestamp) {
        return new Date(timestamp).toLocaleTimeString('en-US', {
            hour: '2-digit',
            minute: '2-digit'
        });
    }

    formatDateTime(date) {
        return date.toLocaleString('en-US');
    }

    escapeHtml(text) {
        const div = document.createElement('div');
        div.textContent = text;
        return div.innerHTML;
    }
}

// Global app instance
let app;

// Initialize application
document.addEventListener('DOMContentLoaded', () => {
    console.log('SecureChat: Initializing secure messaging application');
    console.log('SecureChat: Dual-layer encryption with Web Crypto API');
    console.log('SecureChat: Daily algorithm rotation enabled');
    console.log('SecureChat: Available accounts: 22h51a62c7-2004, 22h51a62c7r-2004r');
    
    app = new SecureChatApp();
    window.app = app; // Make globally accessible for inline event handlers
});

// Handle window resize
window.addEventListener('resize', () => {
    if (window.innerWidth > 1024) {
        document.querySelectorAll('.mobile-open').forEach(el => {
            el.classList.remove('mobile-open');
        });
    }
});

// Handle beforeunload for security
window.addEventListener('beforeunload', (e) => {
    if (app && app.sessions.size > 0) {
        e.preventDefault();
        e.returnValue = 'You have active encrypted sessions. Are you sure you want to leave?';
        return e.returnValue;
    }
});