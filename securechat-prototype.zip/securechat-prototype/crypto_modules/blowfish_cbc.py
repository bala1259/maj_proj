# crypto_modules/blowfish_cbc.py
"""
Blowfish-CBC Encryption Module
Provides encryption using Blowfish cipher in CBC mode
"""

import os
import base64
from Crypto.Cipher import Blowfish
from Crypto.Random import get_random_bytes
from Crypto.Util.Padding import pad, unpad

def generate_key():
    """Generate a 448-bit (56-byte) Blowfish key"""
    return get_random_bytes(56)  # Maximum key size for Blowfish

def encrypt(plaintext, key):
    """
    Encrypt plaintext using Blowfish-CBC
    
    Args:
        plaintext (str or bytes): Data to encrypt
        key (bytes): Blowfish encryption key (4-56 bytes)
        
    Returns:
        dict: Contains 'ciphertext' and 'iv' as base64 strings
    """
    try:
        # Convert string to bytes if needed
        if isinstance(plaintext, str):
            plaintext = plaintext.encode('utf-8')
        
        # Generate random IV (8 bytes for Blowfish)
        iv = get_random_bytes(8)
        
        # Create cipher
        cipher = Blowfish.new(key, Blowfish.MODE_CBC, iv)
        
        # Pad plaintext to block size (8 bytes for Blowfish)
        padded_plaintext = pad(plaintext, 8)
        
        # Encrypt
        ciphertext = cipher.encrypt(padded_plaintext)
        
        return {
            'ciphertext': base64.b64encode(ciphertext).decode('utf-8'),
            'iv': base64.b64encode(iv).decode('utf-8')
        }
    except Exception as e:
        raise Exception(f"Blowfish-CBC encryption failed: {str(e)}")

def decrypt(encrypted_data, key):
    """
    Decrypt Blowfish-CBC encrypted data
    
    Args:
        encrypted_data (dict): Contains 'ciphertext' and 'iv'
        key (bytes): Blowfish decryption key
        
    Returns:
        str: Decrypted plaintext
    """
    try:
        # Decode base64 components
        ciphertext = base64.b64decode(encrypted_data['ciphertext'])
        iv = base64.b64decode(encrypted_data['iv'])
        
        # Create cipher
        cipher = Blowfish.new(key, Blowfish.MODE_CBC, iv)
        
        # Decrypt
        padded_plaintext = cipher.decrypt(ciphertext)
        
        # Remove padding
        plaintext = unpad(padded_plaintext, 8)
        
        return plaintext.decode('utf-8')
    except Exception as e:
        raise Exception(f"Blowfish-CBC decryption failed: {str(e)}")

# Test function
def test():
    """Test Blowfish-CBC encryption/decryption"""
    key = generate_key()
    plaintext = "Hello, Blowfish-CBC encryption!"
    
    # Encrypt
    encrypted = encrypt(plaintext, key)
    print(f"Encrypted: {encrypted}")
    
    # Decrypt
    decrypted = decrypt(encrypted, key)
    print(f"Decrypted: {decrypted}")
    
    assert plaintext == decrypted, "Encryption/decryption test failed"
    print("✓ Blowfish-CBC test passed")

if __name__ == "__main__":
    test()