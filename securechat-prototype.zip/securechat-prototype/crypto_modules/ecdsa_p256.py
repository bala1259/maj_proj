# crypto_modules/ecdsa_p256.py
"""
ECDSA P-256 Digital Signature Module
Provides digital signature capabilities using ECDSA with P-256 curve
"""

import os
import json
import base64
from Crypto.PublicKey import ECC
from Crypto.Signature import DSS
from Crypto.Hash import SHA256


def generate_key():
    """
    Generate an ECDSA P-256 private key
    
    Returns:
        bytes: Private key in DER format
    """
    # Generate ECDSA key pair using P-256 curve
    key = ECC.generate(curve='P-256')
    # Return private key in DER format as bytes
    return key.export_key(format='DER')


def encrypt(plaintext, private_key_der):
    """
    'Encrypt' using ECDSA (actually creates a digital signature)
    For consistency with other modules, we treat signing as encryption
    
    Args:
        plaintext (str or bytes): Data to sign
        private_key_der (bytes): Private key in DER format
        
    Returns:
        dict: Contains 'signature', 'public_key', 'hash' as base64 strings
    """
    try:
        # Convert string to bytes if needed
        if isinstance(plaintext, str):
            plaintext = plaintext.encode('utf-8')
        
        # Import private key from DER format
        private_key = ECC.import_key(private_key_der)
        
        # Create hash of the plaintext
        h = SHA256.new(plaintext)
        
        # Create signature
        signer = DSS.new(private_key, 'fips-186-3')
        signature = signer.sign(h)
        
        # Get public key for verification
        public_key = private_key.public_key()
        
        return {
            'algorithm': 'ECDSA-P256',
            'signature': base64.b64encode(signature).decode('utf-8'),
            'public_key': base64.b64encode(public_key.export_key(format='DER')).decode('utf-8'),
            'hash': base64.b64encode(h.digest()).decode('utf-8'),
            'plaintext': base64.b64encode(plaintext).decode('utf-8')  # Include original data
        }
    except Exception as e:
        raise Exception(f"ECDSA-P256 signing failed: {str(e)}")


def decrypt(signed_data, private_key_der):
    """
    'Decrypt' using ECDSA (actually verifies signature and returns original data)
    For consistency with other modules, we treat verification as decryption
    
    Args:
        signed_data (dict): Contains 'signature', 'public_key', 'hash', 'plaintext'
        private_key_der (bytes): Private key in DER format (not actually needed for verification)
        
    Returns:
        str: Original plaintext if signature is valid
    """
    try:
        # Extract components
        signature = base64.b64decode(signed_data['signature'])
        public_key_der = base64.b64decode(signed_data['public_key'])
        hash_digest = base64.b64decode(signed_data['hash'])
        plaintext = base64.b64decode(signed_data['plaintext'])
        
        # Import public key
        public_key = ECC.import_key(public_key_der)
        
        # Verify signature
        verifier = DSS.new(public_key, 'fips-186-3')
        
        # Create hash object with the original digest
        h = SHA256.new()
        h.digest = lambda: hash_digest  # Override digest method
        
        # Verify the signature
        try:
            verifier.verify(h, signature)
            # If verification succeeds, return original plaintext
            return plaintext.decode('utf-8')
        except (ValueError, TypeError):
            raise Exception("Signature verification failed - data may be tampered with")
            
    except Exception as e:
        raise Exception(f"ECDSA-P256 verification failed: {str(e)}")


def test():
    """Test ECDSA-P256 signing/verification"""
    # Generate key pair
    private_key = generate_key()
    plaintext = "Hello, SecureChat with ECDSA P-256!"
    
    print(f"Original: {plaintext}")
    
    # Sign (encrypt)
    signed = encrypt(plaintext, private_key)
    print(f"Signed: {signed['algorithm']}")
    
    # Verify (decrypt)
    verified = decrypt(signed, private_key)
    print(f"Verified: {verified}")
    
    # Test integrity
    assert plaintext == verified, "Signing/verification test failed"
    print("✓ ECDSA-P256 test passed")


if __name__ == "__main__":
    test()
