# crypto_modules/aes_gcm.py
# AES-256-GCM encryption implementation

import os
import base64
from cryptography.hazmat.primitives.ciphers import Cipher, algorithms, modes
from cryptography.hazmat.backends import default_backend

def generate_key():
    """Generate a random 256-bit AES key"""
    return os.urandom(32)  # 256 bits = 32 bytes

def generate_nonce():
    """Generate a random 96-bit nonce for GCM"""
    return os.urandom(12)  # 96 bits = 12 bytes

def encrypt(plaintext, key):
    """
    Encrypt plaintext using AES-256-GCM
    
    Args:
        plaintext (bytes or str): Data to encrypt
        key (bytes): 256-bit encryption key
        
    Returns:
        dict: Contains nonce, ciphertext, and tag
    """
    if isinstance(plaintext, str):
        plaintext = plaintext.encode('utf-8')
    
    if len(key) != 32:
        raise ValueError("Key must be 32 bytes (256 bits)")
    
    # Generate random nonce
    nonce = generate_nonce()
    
    # Create cipher
    cipher = Cipher(
        algorithms.AES(key),
        modes.GCM(nonce),
        backend=default_backend()
    )
    
    # Encrypt
    encryptor = cipher.encryptor()
    ciphertext = encryptor.update(plaintext) + encryptor.finalize()
    
    # Return as base64-encoded dict for JSON serialization
    return {
        'algorithm': 'AES-256-GCM',
        'nonce': base64.b64encode(nonce).decode('utf-8'),
        'ciphertext': base64.b64encode(ciphertext).decode('utf-8'),
        'tag': base64.b64encode(encryptor.tag).decode('utf-8')
    }

def decrypt(encrypted_data, key):
    """
    Decrypt data encrypted with AES-256-GCM
    
    Args:
        encrypted_data (dict): Contains nonce, ciphertext, and tag
        key (bytes): 256-bit decryption key
        
    Returns:
        str: Decrypted plaintext
    """
    if len(key) != 32:
        raise ValueError("Key must be 32 bytes (256 bits)")
    
    try:
        # Decode from base64
        nonce = base64.b64decode(encrypted_data['nonce'])
        ciphertext = base64.b64decode(encrypted_data['ciphertext'])
        tag = base64.b64decode(encrypted_data['tag'])
        
        # Create cipher
        cipher = Cipher(
            algorithms.AES(key),
            modes.GCM(nonce, tag),
            backend=default_backend()
        )
        
        # Decrypt
        decryptor = cipher.decryptor()
        plaintext = decryptor.update(ciphertext) + decryptor.finalize()
        
        return plaintext.decode('utf-8')
        
    except Exception as e:
        raise ValueError(f"Decryption failed: {str(e)}")

def encrypt_raw(plaintext_bytes, key):
    """
    Raw encryption for chaining with other algorithms
    
    Args:
        plaintext_bytes (bytes): Raw data to encrypt
        key (bytes): 256-bit encryption key
        
    Returns:
        bytes: Encrypted data (nonce + tag + ciphertext)
    """
    if len(key) != 32:
        raise ValueError("Key must be 32 bytes (256 bits)")
    
    nonce = generate_nonce()
    
    cipher = Cipher(
        algorithms.AES(key),
        modes.GCM(nonce),
        backend=default_backend()
    )
    
    encryptor = cipher.encryptor()
    ciphertext = encryptor.update(plaintext_bytes) + encryptor.finalize()
    
    # Return as concatenated bytes: nonce (12) + tag (16) + ciphertext
    return nonce + encryptor.tag + ciphertext

def decrypt_raw(encrypted_bytes, key):
    """
    Raw decryption for chaining with other algorithms
    
    Args:
        encrypted_bytes (bytes): Encrypted data from encrypt_raw
        key (bytes): 256-bit decryption key
        
    Returns:
        bytes: Decrypted plaintext
    """
    if len(key) != 32:
        raise ValueError("Key must be 32 bytes (256 bits)")
    
    if len(encrypted_bytes) < 28:  # 12 + 16 minimum
        raise ValueError("Invalid encrypted data length")
    
    # Extract components
    nonce = encrypted_bytes[:12]
    tag = encrypted_bytes[12:28]
    ciphertext = encrypted_bytes[28:]
    
    cipher = Cipher(
        algorithms.AES(key),
        modes.GCM(nonce, tag),
        backend=default_backend()
    )
    
    decryptor = cipher.decryptor()
    return decryptor.update(ciphertext) + decryptor.finalize()

# Test function
def test_aes_gcm():
    """Test AES-GCM implementation"""
    key = generate_key()
    message = "Hello, SecureChat! This is a test message."
    
    # Test JSON-friendly encryption
    encrypted = encrypt(message, key)
    decrypted = decrypt(encrypted, key)
    
    print(f"Original: {message}")
    print(f"Encrypted: {encrypted}")
    print(f"Decrypted: {decrypted}")
    print(f"Match: {message == decrypted}")
    
    # Test raw encryption
    raw_encrypted = encrypt_raw(message.encode(), key)
    raw_decrypted = decrypt_raw(raw_encrypted, key)
    
    print(f"Raw match: {message == raw_decrypted.decode()}")

if __name__ == "__main__":
    test_aes_gcm()