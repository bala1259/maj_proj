# crypto_modules/chacha20_poly1305.py
"""
ChaCha20-Poly1305 Encryption Module
Provides authenticated encryption using ChaCha20 stream cipher with Poly1305 MAC
"""

import os
import base64
from Crypto.Cipher import ChaCha20_Poly1305
from Crypto.Random import get_random_bytes

def generate_key():
    """Generate a 256-bit ChaCha20 key"""
    return get_random_bytes(32)  # 256 bits = 32 bytes

def encrypt(plaintext, key):
    """
    Encrypt plaintext using ChaCha20-Poly1305
    
    Args:
        plaintext (str or bytes): Data to encrypt
        key (bytes): 256-bit encryption key
        
    Returns:
        dict: Contains 'ciphertext', 'nonce', 'tag' as base64 strings
    """
    try:
        # Convert string to bytes if needed
        if isinstance(plaintext, str):
            plaintext = plaintext.encode('utf-8')
        
        # Create cipher with random nonce (generated automatically)
        cipher = ChaCha20_Poly1305.new(key=key)
        
        # Encrypt and get authentication tag
        ciphertext, tag = cipher.encrypt_and_digest(plaintext)
        
        return {
            'algorithm': 'ChaCha20-Poly1305',
            'ciphertext': base64.b64encode(ciphertext).decode('utf-8'),
            'nonce': base64.b64encode(cipher.nonce).decode('utf-8'),  # nonce is auto-generated
            'tag': base64.b64encode(tag).decode('utf-8')
        }
    except Exception as e:
        raise Exception(f"ChaCha20-Poly1305 encryption failed: {str(e)}")

def decrypt(encrypted_data, key):
    """
    Decrypt ChaCha20-Poly1305 encrypted data
    
    Args:
        encrypted_data (dict): Contains 'ciphertext', 'nonce', 'tag'
        key (bytes): 256-bit decryption key
        
    Returns:
        str: Decrypted plaintext
    """
    try:
        # Decode base64 components
        ciphertext = base64.b64decode(encrypted_data['ciphertext'])
        nonce = base64.b64decode(encrypted_data['nonce'])
        tag = base64.b64decode(encrypted_data['tag'])
        
        # Create cipher with original nonce
        cipher = ChaCha20_Poly1305.new(key=key, nonce=nonce)
        
        # Decrypt and verify
        plaintext = cipher.decrypt_and_verify(ciphertext, tag)
        
        return plaintext.decode('utf-8')
    except Exception as e:
        raise Exception(f"ChaCha20-Poly1305 decryption failed: {str(e)}")

# Test function
def test():
    """Test ChaCha20-Poly1305 encryption/decryption"""
    key = generate_key()
    plaintext = "Hello, SecureChat with ChaCha20!"
    
    # Encrypt
    encrypted = encrypt(plaintext, key)
    print(f"Encrypted: {encrypted}")
    
    # Decrypt
    decrypted = decrypt(encrypted, key)
    print(f"Decrypted: {decrypted}")
    
    assert plaintext == decrypted, "Encryption/decryption test failed"
    print("✓ ChaCha20-Poly1305 test passed")

if __name__ == "__main__":
    test()