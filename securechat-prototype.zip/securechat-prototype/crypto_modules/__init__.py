# crypto_modules/__init__.py
"""
Cryptographic Modules Package
Contains implementations for various encryption algorithms.
"""

import warnings
import importlib
import sys
import os

# Add the crypto_modules directory to Python path if not already there
_current_dir = os.path.dirname(__file__)
if _current_dir not in sys.path:
    sys.path.insert(0, _current_dir)

# Registry of available algorithms
CRYPTO_MODULES = {
    'aes_gcm': 'AES-256-GCM encryption',
    'chacha20_poly1305': 'ChaCha20-Poly1305 encryption', 
    'rsa_oaep': 'RSA-2048-OAEP encryption',
    'ecdsa_p256': 'ECDSA-P256 signatures',
    'blowfish_cbc': 'Blowfish-CBC encryption'
}

def load_module(module_name):
    """
    Dynamically load a crypto module
    
    Args:
        module_name (str): Name of the module to load
        
    Returns:
        module: The loaded module or None if failed
    """
    try:
        # Try absolute import first
        return importlib.import_module(f'crypto_modules.{module_name}')
    except ImportError:
        try:
            # Try relative import
            return importlib.import_module(f'.{module_name}', package='crypto_modules')
        except ImportError:
            try:
                # Try direct import (if in same directory)
                return importlib.import_module(module_name)
            except ImportError as e:
                warnings.warn(f"Could not import {module_name}: {e}")
                return None

def get_available_modules():
    """Return list of successfully loadable crypto modules."""
    available = []
    for module_name in CRYPTO_MODULES.keys():
        module = load_module(module_name)
        if module is not None:
            available.append(module_name)
    return available

def get_module(module_name):
    """
    Get a specific crypto module
    
    Args:
        module_name (str): Name of the module
        
    Returns:
        module: The loaded module
        
    Raises:
        ImportError: If module cannot be loaded
    """
    module = load_module(module_name)
    if module is None:
        raise ImportError(f"Cannot load crypto module: {module_name}")
    return module

# Initialize module cache
_module_cache = {}

def get_cached_module(module_name):
    """Get a module from cache or load it"""
    if module_name not in _module_cache:
        _module_cache[module_name] = load_module(module_name)
    return _module_cache[module_name]

# Expose main functions for easy access
def encrypt_with_algorithm(algorithm_name, plaintext, key):
    """
    Encrypt using specified algorithm
    
    Args:
        algorithm_name (str): Name of the algorithm module
        plaintext: Data to encrypt
        key: Encryption key
        
    Returns:
        Encrypted data in algorithm-specific format
    """
    module = get_module(algorithm_name)
    if hasattr(module, 'encrypt'):
        return module.encrypt(plaintext, key)
    else:
        raise AttributeError(f"Module {algorithm_name} has no encrypt function")

def decrypt_with_algorithm(algorithm_name, encrypted_data, key):
    """
    Decrypt using specified algorithm
    
    Args:
        algorithm_name (str): Name of the algorithm module
        encrypted_data: Data to decrypt
        key: Decryption key
        
    Returns:
        Decrypted plaintext
    """
    module = get_module(algorithm_name)
    if hasattr(module, 'decrypt'):
        return module.decrypt(encrypted_data, key)
    else:
        raise AttributeError(f"Module {algorithm_name} has no decrypt function")

# Test all available modules on import
def test_modules():
    """Test all available crypto modules"""
    print("Testing crypto modules...")
    available = get_available_modules()
    print(f"Available modules: {available}")
    
    for module_name in available:
        try:
            module = get_module(module_name)
            if hasattr(module, 'test'):
                print(f"Testing {module_name}...")
                module.test()
            else:
                print(f"Module {module_name} has no test function")
        except Exception as e:
            print(f"Test failed for {module_name}: {e}")

# Export commonly used items
__all__ = [
    'CRYPTO_MODULES', 
    'get_available_modules', 
    'get_module', 
    'get_cached_module',
    'load_module',
    'encrypt_with_algorithm',
    'decrypt_with_algorithm',
    'test_modules'
]

# Initialize available modules list
AVAILABLE_MODULES = get_available_modules()
# Make get_module directly importable:  from crypto_modules import get_module
globals()["get_module"] = get_module      # ← add this line


if __name__ == "__main__":
    test_modules()