# crypto_modules/rsa_oaep.py
"""
RSA-OAEP Encryption Module
Provides public key encryption using RSA with OAEP padding
"""

import base64
from Crypto.PublicKey import RSA
from Crypto.Cipher import PKCS1_OAEP
from Crypto.Hash import SHA256

def generate_key_pair(key_size=2048):
    """
    Generate RSA key pair
    
    Args:
        key_size (int): Key size in bits (default: 2048)
        
    Returns:
        tuple: (private_key, public_key) as RSA objects
    """
    key = RSA.generate(key_size)
    return key, key.publickey()

def export_key(key, password=None):
    """
    Export RSA key to PEM format
    
    Args:
        key: RSA key object
        password (str): Optional password for private key
        
    Returns:
        str: PEM formatted key
    """
    if password:
        return key.export_key(passphrase=password).decode('utf-8')
    return key.export_key().decode('utf-8')

def import_key(pem_data, password=None):
    """
    Import RSA key from PEM format
    
    Args:
        pem_data (str): PEM formatted key data
        password (str): Optional password for private key
        
    Returns:
        RSA key object
    """
    if password:
        return RSA.import_key(pem_data.encode('utf-8'), passphrase=password)
    return RSA.import_key(pem_data.encode('utf-8'))

def encrypt(plaintext, public_key):
    """
    Encrypt plaintext using RSA-OAEP
    
    Args:
        plaintext (str or bytes): Data to encrypt (max ~190 bytes for 2048-bit key)
        public_key: RSA public key object
        
    Returns:
        dict: Contains 'ciphertext' as base64 string
    """
    try:
        # Convert string to bytes if needed
        if isinstance(plaintext, str):
            plaintext = plaintext.encode('utf-8')
        
        # Check size limit (RSA can only encrypt small amounts)
        max_size = (public_key.size_in_bits() // 8) - 2 * SHA256.digest_size - 2
        if len(plaintext) > max_size:
            raise Exception(f"Data too large for RSA encryption. Max size: {max_size} bytes")
        
        # Create cipher with OAEP padding
        cipher = PKCS1_OAEP.new(public_key, hashAlgo=SHA256)
        
        # Encrypt
        ciphertext = cipher.encrypt(plaintext)
        
        return {
            'ciphertext': base64.b64encode(ciphertext).decode('utf-8')
        }
    except Exception as e:
        raise Exception(f"RSA-OAEP encryption failed: {str(e)}")

def decrypt(encrypted_data, private_key):
    """
    Decrypt RSA-OAEP encrypted data
    
    Args:
        encrypted_data (dict): Contains 'ciphertext' as base64 string
        private_key: RSA private key object
        
    Returns:
        str: Decrypted plaintext
    """
    try:
        # Decode base64 ciphertext
        ciphertext = base64.b64decode(encrypted_data['ciphertext'])
        
        # Create cipher with OAEP padding
        cipher = PKCS1_OAEP.new(private_key, hashAlgo=SHA256)
        
        # Decrypt
        plaintext = cipher.decrypt(ciphertext)
        
        return plaintext.decode('utf-8')
    except Exception as e:
        raise Exception(f"RSA-OAEP decryption failed: {str(e)}")

# Test function
def test():
    """Test RSA-OAEP encryption/decryption"""
    # Generate key pair
    private_key, public_key = generate_key_pair()
    
    plaintext = "Hello, RSA-OAEP encryption!"
    
    # Encrypt
    encrypted = encrypt(plaintext, public_key)
    print(f"Encrypted: {encrypted}")
    
    # Decrypt
    decrypted = decrypt(encrypted, private_key)
    print(f"Decrypted: {decrypted}")
    
    assert plaintext == decrypted, "Encryption/decryption test failed"
    print("✓ RSA-OAEP test passed")

if __name__ == "__main__":
    test()